# OttoDIYArduino
refactoring of the OttoDIY Robot API (Otto9.h & Otto9Humanoid.h) code to be universally cross-platform (all-in-one) and 100% backwards compatible for all Arduino environments
